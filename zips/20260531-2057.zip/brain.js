/* ============================================================
   BRAIN.JS — Renders SVG geometry from CONFIG and wires
   hover/focus interactions. No magic numbers here — all
   values come from config.js.
   ============================================================ */

(function () {
  'use strict';

  const C = CONFIG;
  const SVG_NS = 'http://www.w3.org/2000/svg';

  /* ── Helpers ─────────────────────────────────────────────── */

  function svgEl(tag, attrs) {
    const el = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    return el;
  }

  // Convert leftPoly [dx, y] entries → "x,y x,y …" polygon points string
  // dx is distance LEFT of cx, so x = cx - dx
  function leftPolyPoints() {
    return C.leftPoly
      .map(([dx, y]) => `${C.cx - dx},${y}`)
      .join(' ');
  }

  // Convert rightCurve outer points → smooth SVG path using cardinal spline
  function rightPath() {
    const cx = C.cx + C.seamGap;
    const topY = C.brainTopY;
    const botY = C.brainBotY;

    // Start and end are near-seam points
    const startX = C.cx + C.rightCurve.startDX;
    const endX   = C.cx + C.rightCurve.endDX;

    // Build point list: [startX,topY] → outerPts → [endX,botY]
    const pts = [
      [startX, topY],
      ...C.rightCurve.outerPts.map(([dx, y]) => [C.cx + dx, y]),
      [endX, botY],
    ];

    // Catmull-Rom → cubic bezier conversion for a smooth open curve
    function catmullToBezier(p0, p1, p2, p3, tension) {
      tension = tension ?? 0.4;
      return [
        p1[0] + (p2[0] - p0[0]) * tension,
        p1[1] + (p2[1] - p0[1]) * tension,
        p2[0] - (p3[0] - p1[0]) * tension,
        p2[1] - (p3[1] - p1[1]) * tension,
        p2[0], p2[1],
      ];
    }

    let d = `M ${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[Math.min(pts.length - 1, i + 2)];
      const [cx1, cy1, cx2, cy2, ex, ey] = catmullToBezier(p0, p1, p2, p3);
      d += ` C ${cx1},${cy1} ${cx2},${cy2} ${ex},${ey}`;
    }
    d += ' Z';
    return d;
  }

  // Same path for the clip
  function rightClipPath() { return rightPath(); }

  // Left polygon for clip (same as shape)
  function leftPolyForClip() { return leftPolyPoints(); }

  /* ── Draw hemisphere shapes ──────────────────────────────── */

  function drawLeft() {
    const pts = leftPolyPoints();

    // Main shape
    document.getElementById('shapeLeft').setAttribute('points', pts);
    // Highlight overlay
    document.getElementById('hlShapeLeft').setAttribute('points', pts);
    // Clip polygon
    document.getElementById('polyLeft').setAttribute('points', leftPolyForClip());

    // Ruled lines
    const linesG = document.querySelector('.left-lines');
    linesG.innerHTML = '';
    for (let y = C.brainTopY; y <= C.brainBotY; y += C.lineSpacing) {
      const line = svgEl('line', {
        x1: 0, y1: y,
        x2: C.cx - C.seamGap, y2: y,
      });
      linesG.appendChild(line);
    }

    // Labels — centered in left hemisphere
    const labelX = C.cx - 100;
    const midY = (C.brainTopY + C.brainBotY) / 2;
    const lm = document.getElementById('labelLeftMain');
    const ls = document.getElementById('labelLeftSub');
    lm.setAttribute('x', labelX);
    lm.setAttribute('y', midY);
    lm.textContent = 'LEFT';
    ls.setAttribute('x', labelX);
    ls.setAttribute('y', midY + 14);
    ls.textContent = 'brain';
  }

  function drawRight() {
    const pathD = rightPath();

    document.getElementById('shapeRight').setAttribute('d', pathD);
    document.getElementById('hlShapeRight').setAttribute('d', pathD);
    document.getElementById('pathRightClip').setAttribute('d', rightClipPath());

    // Neuron circles
    const circlesG = document.querySelector('.right-circles');
    circlesG.innerHTML = '';
    C.neurons.forEach(([dx, y, r]) => {
      const circle = svgEl('circle', {
        cx: C.cx + dx,
        cy: y,
        r:  r,
      });
      circlesG.appendChild(circle);
    });

    // Labels
    const labelX = C.cx + 98;
    const midY = (C.brainTopY + C.brainBotY) / 2;
    const rm = document.getElementById('labelRightMain');
    const rs = document.getElementById('labelRightSub');
    rm.setAttribute('x', labelX);
    rm.setAttribute('y', midY);
    rm.textContent = 'RIGHT';
    rs.setAttribute('x', labelX);
    rs.setAttribute('y', midY + 14);
    rs.textContent = 'brain';
  }

  // Build the outer PFC lobe path — a rounded arch that sits atop the brain oval
  // and is mostly behind the hemispheres. Uses an elliptical arc approximation.
  function pfcLobePath() {
    const cx  = C.cx;
    const y0  = C.brainTopY;          // baseline where hemispheres start
    const rise = C.pfcLobeHeight;     // how far above y0 the lobe peaks
    const w    = C.pfcLobeWidth;      // half-width at the baseline
    const lx   = cx - w;
    const rx   = cx + w;
    const peak = y0 - rise;
    // Smooth arch: cubic bezier pulled upward from both ends
    const ctrl = rise * 1.15;
    return `M ${lx},${y0} C ${lx},${y0 - ctrl} ${rx},${y0 - ctrl} ${rx},${y0} Z`;
  }

  // Build one interior arch path at a given vertical offset above brainTopY
  function pfcArchPath(riseOffset, widthFraction) {
    const cx  = C.cx;
    const y0  = C.brainTopY;
    const w   = C.pfcLobeWidth * widthFraction;
    const lx  = cx - w;
    const rx  = cx + w;
    const peak = y0 - riseOffset;
    const ctrl = riseOffset * 1.1;
    return `M ${lx},${y0} C ${lx},${y0 - ctrl} ${rx},${y0 - ctrl} ${rx},${y0}`;
  }

  function drawPfc() {
    const cx  = C.cx;
    const top = C.brainTopY;
    const bot = C.brainBotY;

    // ── Lobe fill (behind hemispheres — draw first) ──
    const lobeEl = document.getElementById('pfcLobe');
    lobeEl.setAttribute('d', pfcLobePath());

    // ── Stacked interior arches ──
    const archesG = document.getElementById('pfcArches');
    archesG.innerHTML = '';
    const n = C.pfcArchCount;
    for (let i = 1; i <= n; i++) {
      // Each arch rises a bit less and is narrower than the one below
      const fraction = i / (n + 1);           // 0..1 going inward
      const riseOff  = C.pfcLobeHeight * fraction * 0.92;
      const widthFrac = 1 - fraction * 0.35;  // narrows toward top
      const el = svgEl('path', {
        d: pfcArchPath(riseOff, widthFrac),
        class: 'pfc-arch',
      });
      archesG.appendChild(el);
    }

    // ── Seam hit target (wide transparent) ──
    const seamHit = document.getElementById('seamLine');
    seamHit.setAttribute('x1', cx); seamHit.setAttribute('y1', top - C.pfcLobeHeight);
    seamHit.setAttribute('x2', cx); seamHit.setAttribute('y2', bot);

    // ── Visible dashed seam ──
    const seamVis = document.getElementById('seamVis');
    seamVis.setAttribute('x1', cx); seamVis.setAttribute('y1', top);
    seamVis.setAttribute('x2', cx); seamVis.setAttribute('y2', bot);

    // ── PFC label — sits in the upper portion of the lobe ──
    const lbl = document.getElementById('pfcLabel');
    lbl.setAttribute('x', cx);
    lbl.setAttribute('y', top - C.pfcLobeHeight * 0.55);
    lbl.textContent = 'PFC';

    // ── Brain stem ──
    const stemTop = bot;
    const stemBot = bot + C.stemLength;
    const stem = document.getElementById('stemLine');
    stem.setAttribute('x1', cx); stem.setAttribute('y1', stemTop);
    stem.setAttribute('x2', cx); stem.setAttribute('y2', stemBot);

    const bulb = document.getElementById('stemBulb');
    bulb.setAttribute('cx', cx);
    bulb.setAttribute('cy', stemBot + C.stemBulbRy * 0.6);
    bulb.setAttribute('rx', 10);
    bulb.setAttribute('ry', C.stemBulbRy);
  }

  function drawCloud() {
    const cl = C.cloud;
    const puffsG = document.getElementById('cloudPuffs');
    puffsG.innerHTML = '';

    cl.puffs.forEach(([dx, dy, rx, ry, dashed]) => {
      const el = svgEl('ellipse', {
        cx: cl.cx + dx,
        cy: cl.cy + dy,
        rx, ry,
        class: dashed ? 'cloud-puff cloud-puff-dash' : 'cloud-puff',
      });
      puffsG.appendChild(el);
    });

    // Label
    const lbl = document.getElementById('cloudLabel');
    lbl.setAttribute('x', cl.cx);
    lbl.setAttribute('y', cl.cy + cl.labelDY);
    lbl.textContent = 'dreams';

    // Rain
    const rainG = document.getElementById('cloudRain');
    rainG.innerHTML = '';
    // Find bottom of cloud puffs
    const cloudBot = cl.cy + Math.max(...cl.puffs.map(([, dy, , ry]) => dy + ry));
    cl.rainLines.forEach(([dx, yTop, yLen]) => {
      const g = document.createElementNS(SVG_NS, 'g');
      const line = svgEl('line', {
        x1: cl.cx + dx, y1: cloudBot + yTop,
        x2: cl.cx + dx, y2: cloudBot + yTop + yLen,
      });
      g.appendChild(line);
      rainG.appendChild(g);
    });
  }

  /* ── Hover / focus interactions ──────────────────────────── */

  function wireZone(zoneId, menuId) {
    const zone = document.getElementById(zoneId);
    const menu = document.getElementById(menuId);
    if (!zone || !menu) return;

    let menuTimer;

    function show() {
      clearTimeout(menuTimer);
      menu.classList.add('visible');
    }
    function hide() {
      menuTimer = setTimeout(() => menu.classList.remove('visible'), 120);
    }

    zone.addEventListener('mouseenter', show);
    zone.addEventListener('mouseleave', hide);
    zone.addEventListener('focus',      show);
    zone.addEventListener('blur',       hide);

    // Keep menu alive when cursor moves into it
    menu.addEventListener('mouseenter', () => clearTimeout(menuTimer));
    menu.addEventListener('mouseleave', hide);
  }

  /* ── Init ────────────────────────────────────────────────── */

  function init() {
    drawLeft();
    drawRight();
    drawPfc();
    drawCloud();

    wireZone('zoneLeft',  'menuLeft');
    wireZone('zoneRight', 'menuRight');
    wireZone('zoneCloud', 'menuCloud');
    wireZone('zonePfc',   'menuPfc');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
