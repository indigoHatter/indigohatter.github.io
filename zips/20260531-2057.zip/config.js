/* ============================================================
   CONFIG.JS — All geometry and layout numbers live here.
   Tweak these values to reshape the brain without touching
   brain.js or any HTML.
   ============================================================ */

const CONFIG = {

  /* ── ViewBox ──────────────────────────────────────────────
     The SVG coordinate space. cx = seam = horizontal center.
     All geometry is derived from these four numbers.          */
  vbWidth:  460,
  vbHeight: 320,
  get cx()  { return this.vbWidth / 2; },   // 230 — seam x

  /* ── Brain vertical extents ──────────────────────────────── */
  brainTopY:    62,   // y of crown / top of hemispheres
  brainBotY:   252,   // y of bottom of hemispheres (both close here)
  seamGap:       8,   // horizontal gap each side pulls away from cx

  /* ── Left hemisphere (polygon vertices) ─────────────────────
     Points are [x-offset-from-cx, y] pairs. Negative x = left.
     Mirror image of right. Add more pairs for smoother outline. */
  leftPoly: [
    // [dx, y]  — dx is distance LEFT of cx (will be cx - dx)
    [  8,  62],   // top, near seam
    [ 82,  54],   // upper shoulder
    [128,  68],   // upper left
    [152,  88],   // cheek
    [168, 112],   // temple
    [172, 140],   // mid
    [168, 170],   // lower mid
    [156, 198],   // lower
    [134, 222],   // chin
    [106, 238],   // jaw
    [ 76, 246],   // bottom left
    [ 50, 248],   // bottom
    [ 36, 244],   // bottom right of left hemi
    [  8, 238],   // near seam bottom
  ],

  /* ── Right hemisphere bezier control points ─────────────────
     Described as offsets from cx (positive = right).
     Format: [type, dx, y] where type = 'M'|'C'|'L'
     Full SVG path built in brain.js                           */
  rightCurve: {
    startDX:   8,    // top near seam (mirrors leftPoly[0])
    endDX:     8,    // bottom near seam (mirrors leftPoly[last])
    // Key outer points [dx, y]:
    outerPts: [
      [ 32,  54],   // upper shoulder
      [ 78,  48],   // top crown right
      [128,  58],   // upper right
      [160,  80],   // temple
      [172, 110],   // cheek
      [174, 142],   // mid bulge
      [168, 172],   // lower mid
      [152, 200],   // lower
      [128, 222],   // chin
      [ 96, 238],   // jaw
      [ 64, 248],   // bottom right
      [ 36, 250],   // bottom
      [  8, 242],   // near seam bottom
    ],
  },

  /* ── PFC lobe ────────────────────────────────────────────────
     The PFC occupies the top-center of the brain oval, mostly
     tucked behind the hemispheres but with its own visible lobe.
     Think of it as the top arc of an oval that the L/R hemispheres
     don't quite cover.                                            */
  pfcLobeWidth:  72,    // half-width of PFC lobe at its widest (each side from cx)
  pfcLobeHeight: 32,    // how far above brainTopY the lobe rises
  pfcArchCount:   4,    // number of stacked arches inside the lobe
  pfcArchSpacing: 6,    // vertical spacing between arches (px)
  pfcCrownWidth: 38,    // arch label / seam crown width (narrower inner arch)
  pfcCrownDip:   14,    // used for seam-top label positioning
  pfcCrownCtrl:  10,    // bezier control point pull for inner crown

  /* ── Brain stem ──────────────────────────────────────────── */
  stemLength:    18,    // px below brainBotY
  stemBulbRy:     6,    // ellipse y-radius of stem bulb

  /* ── Interior ruled lines (left hemisphere) ─────────────── */
  lineSpacing:   16,    // px between horizontal lines
  lineOpacity:  0.40,

  /* ── Interior circles (right hemisphere) ─────────────────── */
  // Each entry: [dx, y, r]  (dx = offset right of cx)
  neurons: [
    [ 38,  88, 5.5],
    [ 64, 100, 3.5],
    [ 88,  88, 4.5],
    [118, 100,   6],
    [ 42, 118,   4],
    [ 70, 122,   7],
    [102, 116, 3.5],
    [134, 118,   5],
    [ 26, 144,   6],
    [ 54, 150,   4],
    [ 82, 144, 5.5],
    [114, 148, 3.5],
    [146, 144, 4.5],
    [ 38, 176,   5],
    [ 66, 182, 3.5],
    [ 96, 178,   6],
    [128, 176,   4],
    [ 50, 210, 4.5],
    [ 78, 218, 3.5],
    [108, 212,   5],
  ],

  /* ── Dream cloud ─────────────────────────────────────────── */
  cloud: {
    // Center of cloud relative to right edge of viewBox
    // [x, y] in absolute viewBox coords
    cx: 390,
    cy:  52,
    // Puff ellipses: [dx, dy, rx, ry, dashed]
    // dx/dy relative to cloud.cx/cy
    puffs: [
      [  0,   0, 24, 14, true ],
      [-18,   8, 15, 10, true ],
      [ 18,   8, 13, 10, true ],
      [  0,  14, 20, 11, false],
    ],
    rainLines: [
      // [dx, yTop, yBot] relative to cloud.cx / cloud bottom
      [-14,  0, 14],
      [ -4,  0, 16],
      [  6,  0, 16],
    ],
    labelDY: 8,    // y offset of label from cloud center
  },
};
