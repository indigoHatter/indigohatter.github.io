/* ============================================================
   SPOKE.JS — Sidebar accordion, active section tracking,
   and theme toggle for all spoke pages.
   ============================================================ */

(function () {
  'use strict';

  /* ── Theme (reuses same localStorage key as splash) ─────── */
  const STORAGE_KEY = 'pw-theme';
  const DARK  = 'theme-dark';
  const LIGHT = 'theme-light';

  function applyTheme(theme) {
    document.body.classList.remove(DARK, LIGHT);
    document.body.classList.add(theme);
    try { localStorage.setItem(STORAGE_KEY, theme); } catch { /* noop */ }
    const btn = document.getElementById('sidebarThemeBtn');
    if (btn) btn.textContent = theme === DARK ? '☀ light' : '☽ dark';
  }

  function initTheme() {
    let stored;
    try { stored = localStorage.getItem(STORAGE_KEY); } catch { /* noop */ }
    if (stored === LIGHT || stored === DARK) {
      applyTheme(stored);
    } else {
      applyTheme(window.matchMedia('(prefers-color-scheme: dark)').matches ? DARK : LIGHT);
    }
    const btn = document.getElementById('sidebarThemeBtn');
    if (btn) {
      btn.addEventListener('click', () => {
        applyTheme(document.body.classList.contains(DARK) ? LIGHT : DARK);
      });
    }
  }

  /* ── Sidebar accordion ───────────────────────────────────── */
  function initSidebar() {
    const triggers = document.querySelectorAll('.sidebar-zone-trigger');
    triggers.forEach(trigger => {
      const zone = trigger.closest('.sidebar-zone');
      // Current zone is always expanded, no toggle needed
      if (zone.classList.contains('is-current')) return;

      trigger.addEventListener('click', () => {
        const isOpen = zone.classList.contains('is-open');
        // Close all non-current zones first
        document.querySelectorAll('.sidebar-zone:not(.is-current)')
          .forEach(z => z.classList.remove('is-open'));
        // Toggle this one
        if (!isOpen) zone.classList.add('is-open');
      });
    });
  }

  /* ── Active section highlighting via IntersectionObserver ── */
  function initActiveLinks() {
    const sections = document.querySelectorAll('.spoke-section[id]');
    const links    = document.querySelectorAll('.sidebar-links a[href*="#"]');
    if (!sections.length || !links.length) return;

    // Map anchor → link element
    const linkMap = {};
    links.forEach(link => {
      const hash = link.getAttribute('href').split('#')[1];
      if (hash) linkMap[hash] = link;
    });

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const link = linkMap[entry.target.id];
        if (!link) return;
        if (entry.isIntersecting) {
          // Remove active from all, add to this one
          Object.values(linkMap).forEach(l => l.classList.remove('is-active'));
          link.classList.add('is-active');
        }
      });
    }, {
      rootMargin: '-20% 0px -70% 0px',  // trigger when section is in upper 30% of viewport
      threshold: 0,
    });

    sections.forEach(s => observer.observe(s));
  }

  /* ── Init ────────────────────────────────────────────────── */
  function init() {
    initTheme();
    initSidebar();
    initActiveLinks();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
