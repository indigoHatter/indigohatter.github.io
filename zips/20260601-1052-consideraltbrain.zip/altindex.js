/* ============================================================
   ALTINDEX.JS — Hover/focus menu wiring for altindex.html.
   Simpler than brain.js — no geometry generation needed,
   everything is static SVG. Just wires the show/hide logic.
   ============================================================ */

(function () {
  'use strict';

  /* Exposed globally so SVG inline handlers can call them */
  window.showMenu = function (menuId) {
    var menu = document.getElementById(menuId);
    if (menu) menu.classList.add('visible');
  };

  window.hideMenu = function (menuId) {
    var menu = document.getElementById(menuId);
    if (menu) {
      /* Small delay so cursor can move into menu without it vanishing */
      menu._hideTimer = setTimeout(function () {
        menu.classList.remove('visible');
      }, 120);
    }
  };

  function keepOpen(menuId) {
    var menu = document.getElementById(menuId);
    if (menu && menu._hideTimer) {
      clearTimeout(menu._hideTimer);
      menu._hideTimer = null;
    }
  }

  function init() {
    /* Wire menus to keep themselves open when hovered */
    var menus = document.querySelectorAll('.brain-menu');
    menus.forEach(function (menu) {
      menu.addEventListener('mouseenter', function () {
        keepOpen(menu.id);
      });
      menu.addEventListener('mouseleave', function () {
        hideMenu(menu.id);
      });
    });

    /* Keyboard / focus support for SVG zones */
    var zones = document.querySelectorAll('.brain-zone');
    zones.forEach(function (zone) {
      var menuId = zone.getAttribute('data-menu');
      if (!menuId) return;
      zone.addEventListener('focus',  function () { showMenu(menuId); });
      zone.addEventListener('blur',   function () { hideMenu(menuId); });
    });

    /* Theme toggle */
    var btn = document.getElementById('themeToggle');
    if (btn) {
      var DARK  = 'theme-dark';
      var LIGHT = 'theme-light';
      var KEY   = 'pw-theme';
      btn.addEventListener('click', function () {
        var isDark = document.body.classList.contains(DARK);
        var next   = isDark ? LIGHT : DARK;
        document.body.classList.remove(DARK, LIGHT);
        document.body.classList.add(next);
        try { localStorage.setItem(KEY, next); } catch (e) { /* noop */ }
      });

      /* Apply stored preference */
      var stored;
      try { stored = localStorage.getItem(KEY); } catch (e) { /* noop */ }
      if (stored === LIGHT || stored === DARK) {
        document.body.classList.remove(DARK, LIGHT);
        document.body.classList.add(stored);
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

}());
