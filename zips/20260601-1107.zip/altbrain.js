/* ============================================================
   ALTINDEX.JS — Hover/focus menu wiring for altindex.html.
   Theme toggle is handled by theme.js (shared across all pages).
   This file only manages the show/hide logic for brain menus.
   ============================================================ */

(function () {
  'use strict';

  /* Exposed globally so SVG inline onmouseenter/leave can call them */
  window.showMenu = function (menuId) {
    var menu = document.getElementById(menuId);
    if (!menu) return;
    if (menu._hideTimer) {
      clearTimeout(menu._hideTimer);
      menu._hideTimer = null;
    }
    menu.classList.add('visible');
  };

  window.hideMenu = function (menuId) {
    var menu = document.getElementById(menuId);
    if (!menu) return;
    menu._hideTimer = setTimeout(function () {
      menu.classList.remove('visible');
    }, 120);
  };

  function init() {
    /* Keep menus alive when cursor moves into them */
    document.querySelectorAll('.brain-menu').forEach(function (menu) {
      menu.addEventListener('mouseenter', function () {
        window.showMenu(menu.id);
      });
      menu.addEventListener('mouseleave', function () {
        window.hideMenu(menu.id);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

}());
